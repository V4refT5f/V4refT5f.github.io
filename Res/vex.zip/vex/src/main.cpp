/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\Administrator                                    */
/*    Created:      Fri Jun 23 2023                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// ESP32                motor         20              
// RearLeft             motor         13              
// Arm                  motor         6               
// RearRight            motor         18              
// FrontLeft            motor         1               
// FrontRight           motor         10              
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
#include <string.h>

using namespace vex;

#define COMMAND_MAX_LEN 45
#define DISPLAY_MAX_LINES 12

#define BAUDRATE 115200

typedef enum CMD {
  UNDEF,
  VEHICLE_MOTION,
  WHEELSPEED
} CMD;

char const *parseCommand(char * command) {
  
  const char *delim = " ";
  char *ptr = NULL;
  ptr = strtok(command, delim);

  int argIndex = 0;
  bool sufficientArg = false;
  CMD commandIndex = UNDEF;

  if (ptr == NULL) { return "Command seems to be empty."; }

  while (ptr != NULL) {

    if (argIndex == 0) {
      if (strcmp(ptr, "VehicleMotion") == 0) {commandIndex = VEHICLE_MOTION; } else
      if (strcmp(ptr, "WheelSpeed") == 0) {commandIndex = WHEELSPEED;} else
      {commandIndex = UNDEF; return "Unknown command.";}
    }

    else {
      switch (commandIndex) {

        case VEHICLE_MOTION:
        if (argIndex == 1) {
          if (strlen(ptr) != 1) {return "Unknown parameter.";}
          switch(ptr[0]) {

            case 'P':  // Park
            RearLeft.stop();
            RearRight.stop();
            FrontLeft.stop();
            FrontRight.stop();
            break;

            case 'F':  // Front
            RearLeft.spin(forward);
            RearRight.spin(forward);
            FrontLeft.spin(forward);
            FrontRight.spin(forward);
            break;

            case 'B':  // Back
            RearLeft.spin(reverse);
            RearRight.spin(reverse);
            FrontLeft.spin(reverse);
            FrontRight.spin(reverse);
            break;

            case 'L':  // Left
            RearLeft.spin(reverse);
            RearRight.spin(forward);
            FrontLeft.spin(forward);
            FrontRight.spin(reverse);
            break;

            case 'R':  // Right
            RearLeft.spin(forward);
            RearRight.spin(reverse);
            FrontLeft.spin(reverse);
            FrontRight.spin(forward);
            break;

            case 'S':  // Clockwise(Shun Shi Zhen)
            RearLeft.spin(forward);
            RearRight.spin(reverse);
            FrontLeft.spin(forward);
            FrontRight.spin(reverse);
            break;

            case 'N':  // Counterclockwise(Ni Shi Zhen)
            RearLeft.spin(reverse);
            RearRight.spin(forward);
            FrontLeft.spin(reverse);
            FrontRight.spin(forward);
            break;

            default:
            return "Unknown parameter.";
            break;
          }
          sufficientArg = true;
        }
        
        break;

        case WHEELSPEED:
        typedef enum WHEEL {ALL, FR, FL, RR, RL} WHEEL;
        WHEEL targetWheel;

        if (argIndex == 1) {
          targetWheel = ALL; 
          if (strcmp(ptr, "All") == 0) {targetWheel = ALL; } else
          if (strcmp(ptr, "FR") == 0) {targetWheel = FR; } else
          if (strcmp(ptr, "FL") == 0) {targetWheel = FL; } else
          if (strcmp(ptr, "RR") == 0) {targetWheel = RR; } else
          if (strcmp(ptr, "RL") == 0) {targetWheel = RL; } else
          {targetWheel = ALL; }
        } else
        if (argIndex == 2) {
          unsigned int spd = atoi(ptr);
          if (spd >= 100) {spd = 100;}
          switch (targetWheel) {
            default:
            case ALL:
            RearLeft.setVelocity(spd, percent);
            RearRight.setVelocity(spd, percent);
            FrontLeft.setVelocity(spd, percent);
            FrontRight.setVelocity(spd, percent);
            break;
            
            case RL:
            RearLeft.setVelocity(spd, percent);
            break;

            case RR:
            RearRight.setVelocity(spd, percent);
            break;

            case FL:
            FrontLeft.setVelocity(spd, percent);
            break;

            case FR:
            FrontRight.setVelocity(spd, percent);
            break;

            
          }
          sufficientArg = true;
        }
        break;

        case UNDEF:
        return "Unknown command.";
        break;

        default:
        return "This command has no parameter.";
        break;
      }
    }

    ptr = strtok(NULL, delim);
    argIndex ++;
  }

  if (sufficientArg == false) {return "Insufficient arguments.";}

  return "OK.";
}

int main() {

  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  RearLeft.setVelocity(10,percent);
  RearRight.setVelocity(10,percent);
  FrontLeft.setVelocity(10,percent);
  FrontRight.setVelocity(10,percent);


  vexGenericSerialEnable(ESP32.index(), 0);
  vexGenericSerialBaudrate(ESP32.index(), BAUDRATE);

  static char thisCommand[COMMAND_MAX_LEN + 1];


  for (int i = 0; i < COMMAND_MAX_LEN; i++) {
    thisCommand[i] = ' ';
  }

  while (1) {
    for (int j = 0; j < DISPLAY_MAX_LINES; j++) {

      for (int i = 0; i < COMMAND_MAX_LEN; i++){
        thisCommand[i] = ' ';
      }

      bool endOfCommand = false;

      for (int i = 0; i < COMMAND_MAX_LEN; i++) {
        
        // Wait until there's something to receive and read the character inputed.
        while (vexGenericSerialReceiveAvail(ESP32.index()) == 0) {}
        thisCommand[i] = vexGenericSerialReadChar(ESP32.index());

        // Handle the 'NULL' char exception.
        if (thisCommand[i] == 0) { thisCommand[i] = '_'; }

        // Handle the Too Long exception.
        if (i == COMMAND_MAX_LEN - 1) { endOfCommand = true; }

        // Handle the normal EOC event (two spacebars).
        if ((i != 0) && (thisCommand[i] == ' ')) { if (thisCommand[i - 1] == ' ') { endOfCommand = true; } }

        if (endOfCommand) {
          Brain.Screen.printAt( 20, 20 + 20 * j, thisCommand );
          j = (j + 1) % DISPLAY_MAX_LINES;
          char *temp = (char*) malloc((COMMAND_MAX_LEN + 1) * sizeof(char));
          strcpy(temp, thisCommand);
          Brain.Screen.printAt( 20, 20 + 20 * j, parseCommand(temp) );
          free(temp);
          break;
        }

      }


    }
  }

}


