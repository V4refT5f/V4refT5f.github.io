

#include <string.h>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>
#include <stdbool.h>


#define COMMAND_MAX_LEN 45
#define DISPLAY_MAX_LINES 12


typedef enum CMD {
  UNDEF,
  VEHICLE_MOTION,
  WHEELSPEED,
  AUTOTSK
} CMD;

typedef struct timeBoundTask timeBoundTask;

typedef struct timeBoundTask {
  unsigned int beginTime;
  unsigned int endTime;
  int beginValue;
  int endValue;
  int lastValue;
  char * formattedCommandSection1;
  char * formattedCommandSection2;
  timeBoundTask * nextptr;
  timeBoundTask * prevptr;
} timeBoundTask;

timeBoundTask rootTBT = {
  0, 0, 0, 0, 0, NULL, NULL, NULL, NULL
};

timeBoundTask *getTBTByIndex(unsigned int index, timeBoundTask * start) {
  if ((index == 0) || (start->nextptr == NULL)) {return start;}
  else {return getTBTByIndex(index - 1, start->nextptr);}
}

timeBoundTask *getIndexByTBT(unsigned int * index, timeBoundTask * start) {
  if (start->prevptr == NULL) {return start;}
  else {(*index) ++; return getIndexByTBT(index, start->prevptr);}
}

timeBoundTask *getLastTBT(timeBoundTask * start) {
  if (start->nextptr == NULL) {return start;}
  else {return getLastTBT(start->nextptr);}
}

int deleteTBT(timeBoundTask * target) {
  if (target->prevptr == NULL) {return -1;}    
  (target->prevptr)->nextptr = (target->nextptr);
  if (target->nextptr != NULL) {
    (target->nextptr)->prevptr = (target->prevptr);
  }
  free(target->formattedCommandSection1);
  free(target->formattedCommandSection2);
  free(target);
  return 0;
}

int appendAfterTBT(timeBoundTask * source, timeBoundTask * target) {
  if (target->nextptr != NULL) {
    source->nextptr = (target->nextptr)->prevptr;
    (target->nextptr)->prevptr = source;
  }
  target->nextptr = source;
  source->prevptr = target;
  return 0;
}

int getCurrentValueByTime(unsigned int beginTime, unsigned int endTime, int beginValue, int endValue) {
  int returnval = (int) (beginValue + (endValue - beginValue) * ((int)GetTickCount() - (int)beginTime) / ((int)endTime - (int)beginTime));
  if ((int)GetTickCount() >= endTime) {returnval = endValue;}
  return returnval;
}

char const *parseCommand(char * command);

int refreshTBT(timeBoundTask * start) {
  
  if (start == NULL) {return 0;}
  if (start->endTime == 0) {return refreshTBT(start->nextptr);}

  char *tempCommand = (char*) malloc(COMMAND_MAX_LEN * sizeof(char));
  char *oritempCommand = tempCommand;

  strcpy(tempCommand, start->formattedCommandSection1);

  int currentval = getCurrentValueByTime(start->beginTime, start->endTime, start->beginValue, start->endValue);
  sprintf(tempCommand + strlen(tempCommand), "%ld", currentval);

  strcat(tempCommand, start->formattedCommandSection2);

  if (start->lastValue != currentval) {
    printf("\n[Parser V716a] Debug: TBT->parseCommand called.\n\n");
    int debug_index = 0;
    getIndexByTBT(&debug_index, start);
    printf("[Parser V716a] Debug: Caller: Currentval: %d.\n", currentval);
    printf("[Parser V716a] Debug: Caller: TBT-Address: %d.\n", start);
    printf("[Parser V716a] Debug: Caller: TBT-Index: %d.\n\n", debug_index);
    parseCommand(tempCommand);
  }
  free(oritempCommand);
  start->lastValue = currentval;

  timeBoundTask *next = start->nextptr;
  if ((int)GetTickCount() >= start->endTime) {
    printf("[Parser V716a] Debug: pre-Delete TBT call.\n");
    deleteTBT(start);
  }
  return refreshTBT(next);
}

char const *taskMacroParse(char * command) {

  char *start = strchr(command, '[');
  char *end = strchr(command, ']');
  if ((start == NULL) || (end == NULL) || (end < start)) { return NULL; }

  char *substring = (char*) malloc((end - start) * sizeof(char));
  strncpy(substring, start + 1, end - start - 1);
  substring[end - start - 1] = '\0';
  

  char *formattedCommand1 = (char*) malloc((strlen(command)) * sizeof(char));
  char *formattedCommand2 = (char*) malloc((strlen(command)) * sizeof(char));
  strncpy(formattedCommand1, command, start - command); 
  formattedCommand1[start - command] = '\0';
  strcpy(formattedCommand2, start + strlen(substring) + 2);


  const char *delim = ",";
  char *ptr = NULL;
  ptr = strtok(substring, delim);

  int argIndex = 0;
  bool sufficientArg = false;

  if (ptr == NULL) { free(substring); free(formattedCommand1); free(formattedCommand2); return "[Parser V716a] Task Macro lacks separator."; }

  timeBoundTask *newTBT = (timeBoundTask*) malloc(sizeof(timeBoundTask));

  newTBT->beginTime = GetTickCount();
  newTBT->endTime = GetTickCount();
  newTBT->beginValue = 0;
  newTBT->endValue = 0;
  newTBT->lastValue = 0;
  newTBT->formattedCommandSection1 = formattedCommand1;
  newTBT->formattedCommandSection2 = formattedCommand2;
  newTBT->nextptr = NULL;
  newTBT->prevptr = NULL;


  while (ptr != NULL) {
    switch (argIndex) {
      case 0:
        newTBT->beginValue = atoi(ptr);
        break;
      case 1:
        newTBT->endValue = atoi(ptr);
        break;
      case 2:
        newTBT->endTime += atoi(ptr);
        sufficientArg = true;
        break;
    }
    ptr = strtok(NULL, delim);
    argIndex ++;
  }

  if (sufficientArg != true) { free(substring); free(formattedCommand1); free(formattedCommand2); free(newTBT); return "[Parser V716a] Task Macro lacks sufficient argument."; }

  appendAfterTBT(newTBT, getLastTBT(&rootTBT));

  free(substring);

  return "[Parser V716a] New task created.";
}

// Parse and execute a command.
// The content of char * command needs to be modificable, so don't pass a literal to it.
// Returns an message.
char const *parseCommand(char * command) {

  const char *taskMacResponse = taskMacroParse(command);
  if (taskMacResponse != NULL) {return taskMacResponse;}

  const char *delim = " ";
  char *ptr = NULL;
  ptr = strtok(command, delim);

  int argIndex = 0;
  bool sufficientArg = false;
  CMD commandIndex = UNDEF;

  if (ptr == NULL) { return "[Parser V716a] Command seems to be empty."; }

  // Continue parsing arguments until the end of the command.
  while (ptr != NULL) {

    // The 0th argument should be the name of the command.
    if (argIndex == 0) {
      if (strcmp(ptr, "VehicleMotion") == 0) {commandIndex = VEHICLE_MOTION; } else
      if (strcmp(ptr, "WheelSpeed") == 0) {commandIndex = WHEELSPEED;} else
      if (strcmp(ptr, "AutonomousTask") == 0) {commandIndex = AUTOTSK;} else
      {commandIndex = UNDEF; return "[Parser V716a] Unknown command.";}
    }

    // Parsing the 1st ~ nth argument.
    else {
      switch (commandIndex) {

        // The VehicleMotion command.
        case VEHICLE_MOTION:
        if (argIndex == 1) {
          if (strlen(ptr) != 1) {return "[Parser V716a] Unknown parameter.";}
          switch(ptr[0]) {

            case 'P':  // Park
            printf("<VEXHWI> Parked.\n");
            break;

            case 'F':  // Front
            printf("<VEXHWI> Going forward.\n");
            break;

            case 'B':  // Back
            printf("<VEXHWI> Going backward.\n");
            break;

            case 'L':  // Left
            printf("<VEXHWI> Going left.\n");
            break;

            case 'R':  // Right
            printf("<VEXHWI> Going right.\n");
            break;

            case 'S':  // Clockwise(Shun Shi Zhen)
            printf("<VEXHWI> Spinning clockwise.\n");
            break;

            case 'N':  // Counterclockwise(Ni Shi Zhen)
            printf("<VEXHWI> Spinning counterclockwise.\n");
            break;

            default:
            return "Unknown parameter.";
            break;
          }
          sufficientArg = true;
        }
        
        break;

        // The WheelSpeed command.
        case WHEELSPEED:
        typedef enum WHEEL {ALL, FR, FL, RR, RL} WHEEL;
        WHEEL targetWheel;
        if (argIndex == 1) {
          targetWheel = ALL; 
          if (strcmp(ptr, "All") == 0) {targetWheel = ALL; } else
          if (strcmp(ptr, "FR") == 0) {targetWheel = FR; } else
          if (strcmp(ptr, "FL") == 0) {targetWheel = FL; } else
          if (strcmp(ptr, "RR") == 0) {targetWheel = RR; } else
          if (strcmp(ptr, "RL") == 0) {targetWheel = RL; } else
          {targetWheel = ALL; }
        } else
        if (argIndex == 2) {
          unsigned int spd = atoi(ptr);
          if (spd >= 100) {spd = 100;}
          switch (targetWheel) {
            default:
            case ALL:
            printf("<VEXHWI> Set speed to %d percent for all wheels.\n", spd);
            break;
            
            case RL:
            printf("<VEXHWI> Set speed to %d percent for RL wheel.\n", spd);
            break;

            case RR:
            printf("<VEXHWI> Set speed to %d percent for RR wheel.\n", spd);
            break;

            case FL:
            printf("<VEXHWI> Set speed to %d percent for FL wheel.\n", spd);
            break;

            case FR:
            printf("<VEXHWI> Set speed to %d percent for FR wheel.\n", spd);
            break;

            
          }
          sufficientArg = true;
        }
        break;

        case UNDEF:
        return "[Parser V716a] Unknown command.";
        break;

        default:
        return "[Parser V716a] This command has no parameter.";
        break;
      }
    }

    ptr = strtok(NULL, delim);
    argIndex ++;
  }

  if (sufficientArg == false) {return "[Parser V716a] Insufficient arguments.";}

  return "[Parser V716a] OK.";
}

int main() {


  static char thisCommand[COMMAND_MAX_LEN + 1];


  for (int i = 0; i < COMMAND_MAX_LEN; i++) {
    thisCommand[i] = ' ';
  }

  while (1) {
    for (int j = 0; j < DISPLAY_MAX_LINES; j++) {

      for (int i = 0; i < COMMAND_MAX_LEN; i++){
        thisCommand[i] = ' ';
      }

      bool endOfCommand = false;

      for (int i = 0; i < COMMAND_MAX_LEN; i++) {
        
        // Wait until there's something to receive and read the character commanded.
        while (!kbhit()) { refreshTBT(&rootTBT);}
        thisCommand[i] = getch();

        // Handle the 'NULL' char exception.
        if (thisCommand[i] == 0) { thisCommand[i] = '_'; }

        // Handle the Too Long exception.
        if (i == COMMAND_MAX_LEN - 1) { endOfCommand = true; }

        // Handle the normal EOC event (two spacebars).
        if ((i != 0) && (thisCommand[i] == ' ')) { if (thisCommand[i - 1] == ' ') { endOfCommand = true; } }

        if (endOfCommand) {

          printf("%s\n", thisCommand);
          j = (j + 1) % DISPLAY_MAX_LINES;

          char *temp = (char*) malloc((COMMAND_MAX_LEN + 1) * sizeof(char));
          char *oritemp = temp;
          strcpy(temp, thisCommand);
          printf("%s\n", parseCommand(temp));
          free(oritemp);
          break;
        }

      }


    }
  }

}


