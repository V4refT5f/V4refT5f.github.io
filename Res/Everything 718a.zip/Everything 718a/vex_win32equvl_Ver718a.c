#include <string.h>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>
#include <stdbool.h>
#include <stdint.h>

#define COMMAND_MAX_LEN 100
#define DISPLAY_MAX_LINES 12

#define _VEXSCREEN_LINEC int

#define BAUDRATE 115200


typedef enum CMD {
  UNDEF,
  VEHICLE_MOTION,
  WHEELSET,
  AUTOTSK,
  ECHO,
  JOYSTK
} CMD;

void vexLog(int * j, const char * text) {
  char *outputBuffer = (char*) malloc((strlen(text)+3) * sizeof(char));
  strcpy(outputBuffer, text);
  outputBuffer[strlen(text)+2] = '\0';
  outputBuffer[strlen(text)+1] = '\n';
  outputBuffer[strlen(text)] = ' ';
  printf("%s", outputBuffer);
  free(outputBuffer);
}












typedef struct timeBoundTask timeBoundTask;

typedef struct timeBoundTask {
  uint32_t beginTime;
  uint32_t endTime;
  int32_t beginValue;
  int32_t endValue;
  int32_t lastValue;
  char * formattedCommandSection1;
  char * formattedCommandSection2;
  timeBoundTask * nextptr;
  timeBoundTask * prevptr;
} timeBoundTask;

timeBoundTask rootTBT = {
  0, 0, 0, 0, 0, NULL, NULL, NULL, NULL
};

timeBoundTask *getTBTByIndex(uint32_t index, timeBoundTask * start) {
  if ((index == 0)) {return start;}
  if (start == NULL) {return NULL;}
  else {return getTBTByIndex(index - 1, start->nextptr);}
}

// Returns the first task tracing back from "start".
timeBoundTask *getIndexByTBT(uint32_t * index, timeBoundTask * start) {
  if (start->prevptr == NULL) {return start;}
  else {(*index) ++; return getIndexByTBT(index, start->prevptr);}
}

timeBoundTask *getLastTBT(timeBoundTask * start) {
  if (start->nextptr == NULL) {return start;}
  else {return getLastTBT(start->nextptr);}
}

int deleteTBT(timeBoundTask * target) {
  if (target->prevptr == NULL) {return -1;}    
  (target->prevptr)->nextptr = (target->nextptr);
  if (target->nextptr != NULL) {
    (target->nextptr)->prevptr = (target->prevptr);
  }
  free(target->formattedCommandSection1);
  free(target->formattedCommandSection2);
  free(target);
  return 0;
}

int appendAfterTBT(timeBoundTask * source, timeBoundTask * target) {
  if (target->nextptr != NULL) {
    source->nextptr = (target->nextptr)->prevptr;
    (target->nextptr)->prevptr = source;
  }
  target->nextptr = source;
  source->prevptr = target;
  return 0;
}

timeBoundTask *getTBTByAddress(char * address, timeBoundTask * start) {
  if (start == NULL) {return NULL; }
  int index = 0;
  char *cmpAddrString = (char*) malloc(20);
  while (getTBTByIndex(index, start) != NULL) {
    sprintf(cmpAddrString, "%lu", (uint64_t) getTBTByIndex(index, start));
    if (strcmp(address, cmpAddrString) == 0) {free(cmpAddrString); return getTBTByIndex(index, start); break;}
    index ++;
  }
  free(cmpAddrString); return NULL;
}

int32_t getCurrentValueByTime(uint32_t beginTime, uint32_t endTime, int32_t beginValue, int32_t endValue, bool * enablementFlag) {
  int32_t returnval = (int32_t) (beginValue + (endValue - beginValue) * ((int32_t)GetTickCount() - (int32_t)beginTime) / ((int32_t)endTime - (int32_t)beginTime));
  if (GetTickCount() >= endTime) {returnval = endValue;}
  if (GetTickCount() <= beginTime) {returnval = beginValue; *enablementFlag = false;}
  return returnval;
}

char const *parseCommand(char * command, _VEXSCREEN_LINEC * j);

// Iterate through and refresh all tasks starting from "start".
int refreshTBT(timeBoundTask * start, _VEXSCREEN_LINEC * j) {
  if (start == NULL) {return 0;}
  if (start->endTime == 0) {return refreshTBT(start->nextptr, j);}

  char *tempCommand = (char*) malloc(COMMAND_MAX_LEN * sizeof(char));
  char *oritempCommand = tempCommand;
  bool enablementFlag = true;
  strcpy(tempCommand, start->formattedCommandSection1);
  int32_t currentval = getCurrentValueByTime(start->beginTime, start->endTime, start->beginValue, start->endValue, &enablementFlag);
  sprintf(tempCommand + strlen(tempCommand), "%ld", currentval);
  strcat(tempCommand, start->formattedCommandSection2);
  if ((start->lastValue != currentval) && (enablementFlag)) {parseCommand(tempCommand, j);}
  free(oritempCommand);
  start->lastValue = currentval;

  timeBoundTask *next = start->nextptr;
  if (GetTickCount() >= start->endTime) {
    deleteTBT(start);
  }
  return refreshTBT(next, j);
}

// Detect if there is a task macro in the command.
// Creates a task at the end of the rootTPT linked list.
char const *taskMacroParse(char * command) {

  // Check the basic structure of a task macro. ([XXX])
  char *start = strchr(command, '[');
  char *end = strchr(command, ']');
  if ((start == NULL) || (end == NULL) || (end < start)) { return NULL; }

  // Allocate a piece of memory space for the string between the [ and ].
  char *substring = (char*) malloc((end - start) * sizeof(char));
  strncpy(substring, start + 1, end - start - 1);
  // Attach an \0 at the end of the char array.
  substring[end - start - 1] = '\0';

  // Allocate space for the original command before and after the macro.
  char *formattedCommand1 = (char*) malloc((strlen(command)) * sizeof(char));
  char *formattedCommand2 = (char*) malloc((strlen(command)) * sizeof(char));
  strncpy(formattedCommand1, command, start - command); 
  formattedCommand1[start - command] = '\0';
  strcpy(formattedCommand2, start + strlen(substring) + 2);
  
  // Preparations to parse the macro.
  const char *delim = ",";
  char *ptr = NULL;
  ptr = strtok(substring, delim);

  int argIndex = 0;
  bool sufficientArg = false;

  // if there's nothing inside [], then throw an exception. 
  // Notice that all allocated space MUST be freed before an abnormal exit.
  if (ptr == NULL) { free(substring); free(formattedCommand1); free(formattedCommand2); return "[Parser V718a] Task Macro lacks separator."; }

  // Allocate and config the new task.
  timeBoundTask *newTBT = (timeBoundTask*) malloc(sizeof(timeBoundTask));
  newTBT->beginTime = GetTickCount();
  // By only allowing += operation on endTime, the program ensures that the time will only flow forwards.
  newTBT->endTime = GetTickCount();
  newTBT->beginValue = 0;
  newTBT->endValue = 0;
  newTBT->lastValue = 0;
  newTBT->formattedCommandSection1 = formattedCommand1;
  newTBT->formattedCommandSection2 = formattedCommand2;
  // Its links in a linked list will be set later.
  newTBT->nextptr = NULL;
  newTBT->prevptr = NULL;

  while (ptr != NULL) {

    switch (argIndex) {
      case 0:
        newTBT->beginValue = atoi(ptr);
        break;
      case 1:
        newTBT->endValue = atoi(ptr);
        break;
      case 2:
        newTBT->beginTime += atoi(ptr);
        sufficientArg = true;
        break;
      case 3:
        newTBT->endTime += atoi(ptr);
        sufficientArg = true;
        break;
    }
    ptr = strtok(NULL, delim);
    argIndex ++;
  }

  if (sufficientArg != true) { free(substring); free(formattedCommand1); free(formattedCommand2); free(newTBT); return "[Parser V718a] Task Macro lacks sufficient argument."; }

  // Append the newly created task to the end of the "root" list.
  appendAfterTBT(newTBT, getLastTBT(&rootTBT));

  // After parsing, the space allocated for substring must be freed.
  free(substring);

  return "[Parser V718a] New task created.";
}
















typedef struct JoystickT {
  uint8_t x;
  uint8_t y;
} JoystickT;

static JoystickT carMotionJoystick;

void mapJoystickToWheels(uint8_t x, uint8_t y, int8_t* wheelSpeed) {
  // Normalize x and y to a range of -100 to 100
  int8_t normalizedX = (x - 128) * 100 / 128;
  int8_t normalizedY = (y - 128) * 100 / 128;

  // Adjust wheel speeds based on joystick coordinates
  wheelSpeed[0] = normalizedY + normalizedX; // Front Right wheel
  wheelSpeed[1] = normalizedY - normalizedX; // Front Left wheel
  wheelSpeed[2] = normalizedY + normalizedX; // Rear Right wheel
  wheelSpeed[3] = normalizedY - normalizedX; // Rear Left wheel

    // Limit wheel speeds to the range of -100 to 100
  for (int i = 0; i < 4; i++) {
    if (wheelSpeed[i] > 100) {
      wheelSpeed[i] = 100;
    } else if (wheelSpeed[i] < -100) {
      wheelSpeed[i] = -100;
    }
  }
}

bool processJoystick(int * j) {

  typedef enum WHEEL {FR, FL, RR, RL, ALL} WHEEL;
  char* commandBuf = (char*) malloc(COMMAND_MAX_LEN * sizeof(char));
  int8_t wheelSpeed[ALL] = {0, 0, 0, 0}; 
  mapJoystickToWheels(carMotionJoystick.x, carMotionJoystick.y, wheelSpeed);

  if (wheelSpeed[FR] >= 0) {sprintf(commandBuf, "WheelSet -target FrontR -speed %d -direction Forward", wheelSpeed[FR]);} 
  else {sprintf(commandBuf, "WheelSet -target FrontR -speed %d -direction Reverse", 0 - wheelSpeed[FR]);} 
  parseCommand(commandBuf, j);

  if (wheelSpeed[FL] >= 0) {sprintf(commandBuf, "WheelSet -target FrontL -speed %d -direction Forward", wheelSpeed[FL]);} 
  else {sprintf(commandBuf, "WheelSet -target FrontL -speed %d -direction Reverse", 0 - wheelSpeed[FL]);} 
  parseCommand(commandBuf, j);

  if (wheelSpeed[RR] >= 0) {sprintf(commandBuf, "WheelSet -target RearR -speed %d -direction Forward", wheelSpeed[RR]);} 
  else {sprintf(commandBuf, "WheelSet -target RearR -speed %d -direction Reverse", 0 - wheelSpeed[RR]);} 
  parseCommand(commandBuf, j);

  if (wheelSpeed[RL] >= 0) {sprintf(commandBuf, "WheelSet -target RearL -speed %d -direction Forward", wheelSpeed[RL]);} 
  else {sprintf(commandBuf, "WheelSet -target RearL -speed %d -direction Reverse", 0 - wheelSpeed[RL]);} 
  parseCommand(commandBuf, j);

  return true;
}




















// Looks up the value of a parameter in argTokenList.
// Returns the pointer to the string of the value.
// NULL if nothing is found.
char * lookUpArg(char ** argTokenList, const char * name, int argc, const char * indicator) {
  if (argTokenList == NULL) {return NULL;}
  if (indicator == NULL) {return NULL;}
  for (int i = 0; i < argc; i++) {
    // Check if the token is in the format of a command.
    if (strncmp(*(argTokenList + i), indicator, strlen(indicator)) == 0) {
      if (strncmp((*(argTokenList + i) + strlen(indicator)), name, strlen(name)) == 0) {
        if (i == argc - 1) {return NULL;}
        if (strncmp(*(argTokenList + i + 1), indicator, strlen(indicator)) == 0) {return NULL;}
        return *(argTokenList + i + 1);
      }
    }
  }
  return NULL;
}

// Parse and execute a command.
// The content of char * command needs to be modificable, so don't pass a literal to it.
// Returns an message.
char const *parseCommand(char * command, _VEXSCREEN_LINEC * j) {

  const char *taskMacResponse = taskMacroParse(command);
  // If a macro is detected, then hand over the right to process to taskMacroParse().
  if (taskMacResponse != NULL) {return taskMacResponse;}

  const char *delim = " ";
  char *ptr = NULL;
  ptr = strtok(command, delim);

  CMD commandIndex = UNDEF;

  if (ptr == NULL) { return "[Parser V718a] Command seems to be empty."; }

  // The 0th argument should be the name of the command.

  if ((strcmp(ptr, "VehicleMotion") == 0) || (strcmp(ptr, "VM") == 0)) {commandIndex = VEHICLE_MOTION; } else
  if ((strcmp(ptr, "WheelSet") == 0) || (strcmp(ptr, "WS") == 0)) {commandIndex = WHEELSET;} else
  if ((strcmp(ptr, "AutonomousTask")) == 0 || (strcmp(ptr, "AT") == 0)) {commandIndex = AUTOTSK;} else
  if ((strcmp(ptr, "Echo") == 0) || (strcmp(ptr, "Print") == 0) || (strcmp(ptr, "echo") == 0)) {commandIndex = ECHO;} else
  if ((strcmp(ptr, "Joystick") == 0) || (strcmp(ptr, "JSTK") == 0)) {commandIndex = JOYSTK;} else
  {commandIndex = UNDEF; return "[Parser V718a] Unknown command.";}

  // Throw an no parameter exception.
  ptr = strtok(NULL, delim);
  if (ptr == NULL) { return "[Parser V718a] Command seems to have no parameter."; }

  // Create an argTokenList according to the arguments.
  int argc = 0; // argIndex := argc - 1
  char **argTokenList = (char**) malloc(1 * sizeof(char*));
  while (ptr != NULL) {
    argc ++;
    argTokenList = (char**) realloc(argTokenList, (1 + argc) * sizeof(char*));
    *(argTokenList + argc - 1) = ptr;
    ptr = strtok(NULL, delim);
  }

  switch (commandIndex) {

    // The VehicleMotion command.
    case VEHICLE_MOTION: 
    if (lookUpArg(argTokenList, "type", argc, "-") == NULL) {free(argTokenList); return "[Parser V718a] Command lacks critical argument(s).";} 
    if (strlen(lookUpArg(argTokenList, "type", argc, "-")) != 1) {free(argTokenList); return "[Parser V718a] Unknown parameter.";}
    switch(lookUpArg(argTokenList, "type", argc, "-")[0]) {

            case 'P':  // Park
            printf("<VEXHWI> Parked.\n");
            break;

            case 'F':  // Front
            printf("<VEXHWI> Going forward.\n");
            break;

            case 'B':  // Back
            printf("<VEXHWI> Going backward.\n");
            break;

            case 'L':  // Left
            printf("<VEXHWI> Going left.\n");
            break;

            case 'R':  // Right
            printf("<VEXHWI> Going right.\n");
            break;

            case 'S':  // Clockwise(Shun Shi Zhen)
            printf("<VEXHWI> Spinning clockwise.\n");
            break;

            case 'N':  // Counterclockwise(Ni Shi Zhen)
            printf("<VEXHWI> Spinning counterclockwise.\n");
            break;
      
            default:
            free(argTokenList); return "[Parser V718a] Unknown parameter.";
            break;
    }
    break;

    // The WHEELSET command.
    case WHEELSET:
    #define ALL 4
    #define FR 0
    #define FL 1
    #define RR 2
    #define RL 3
    static bool targetWheel[ALL];
    targetWheel[FR] = true; targetWheel[FL] = true; targetWheel[RR] = true; targetWheel[RL] = true; 
    char * tgwString;
    tgwString = lookUpArg(argTokenList, "target", argc, "-");
    char * speedString;
    speedString = lookUpArg(argTokenList, "speed", argc, "-");
    char * dirString;
    dirString = lookUpArg(argTokenList, "direction", argc, "-");
    if ((speedString == NULL) && (dirString == NULL)) {free(argTokenList); return "[Parser V718a] Command lacks critical argument(s).";} 
    if (tgwString != NULL){if ((strcmp(tgwString, "All") != 0)) {targetWheel[FR] = false; targetWheel[FL] = false; targetWheel[RR] = false; targetWheel[RL] = false; }}

    if (tgwString != NULL){if (strstr(tgwString, "FrontR") != NULL) {targetWheel[FR] = true; }
        if (strstr(tgwString, "FrontL") != NULL) {targetWheel[FL] = true; }
        if (strstr(tgwString, "RearR") != NULL) {targetWheel[RR] = true; }
        if (strstr(tgwString, "RearL") != NULL) {targetWheel[RL] = true; }}

    if (speedString != NULL) {
      uint32_t spd = atoi(speedString);
      if (spd >= 100) {spd = 100;}
      if (targetWheel[RL] == true) {printf("<VEXHWI> Set speed to %d percent for RL wheel.\n", spd);}
      if (targetWheel[RR] == true) {printf("<VEXHWI> Set speed to %d percent for RR wheel.\n", spd);}
      if (targetWheel[FL] == true) {printf("<VEXHWI> Set speed to %d percent for FL wheel.\n", spd);}
      if (targetWheel[FR] == true) {printf("<VEXHWI> Set speed to %d percent for FR wheel.\n", spd);}
    }

        if (dirString != NULL) {
      if (strcmp(dirString, "Forward") == 0) {
        if (targetWheel[RL] == true) {printf("<VEXHWI> Set RL wheel to spin forwards.\n");}
        if (targetWheel[RR] == true) {printf("<VEXHWI> Set RR wheel to spin forwards.\n");}
        if (targetWheel[FL] == true) {printf("<VEXHWI> Set FL wheel to spin forwards.\n");}
        if (targetWheel[FR] == true) {printf("<VEXHWI> Set FR wheel to spin forwards.\n");}
      } else
      if ((strcmp(dirString, "Backward") == 0) || (strcmp(dirString, "Reverse") == 0)) {
        if (targetWheel[RL] == true) {printf("<VEXHWI> Set RL wheel to spin backwards.\n");}
        if (targetWheel[RR] == true) {printf("<VEXHWI> Set RR wheel to spin backwards.\n");}
        if (targetWheel[FL] == true) {printf("<VEXHWI> Set FL wheel to spin backwards.\n");}
        if (targetWheel[FR] == true) {printf("<VEXHWI> Set FR wheel to spin backwards.\n");}
      }
    }
     
    break;

    // The Echo Command.
    case ECHO:
    vexLog(j, " ");
    break;

    // The Joystick Command.
    case JOYSTK:
    char *xString; xString = lookUpArg(argTokenList, "x", argc, "-");
    char *yString; yString = lookUpArg(argTokenList, "y", argc, "-");
    if ((xString == NULL) || (yString == NULL)) {free(argTokenList); return "[Parser V718a] Command lacks critical argument(s).";} 
    carMotionJoystick.x = (int8_t) atoi(xString);
    carMotionJoystick.y = (int8_t) atoi(yString);
    processJoystick(j);
    break;

    // The AutonomousTask Command.
    case AUTOTSK:
    char *infoString; infoString = lookUpArg(argTokenList, "info", argc, "-");
    char *deleteString; deleteString = lookUpArg(argTokenList, "delete", argc, "-");
    if ((infoString == NULL) && (deleteString == NULL)) {free(argTokenList); return "[Parser V718a] Command lacks critical argument(s).";} 

    if (deleteString != NULL) {
      timeBoundTask *currentTBT; currentTBT = getTBTByAddress(deleteString, rootTBT.nextptr);
      if (currentTBT == NULL) {free(argTokenList); return "[Parser V718a] Not a valid timeBoundTask* address.";}
      deleteTBT(currentTBT);
    }

    if (infoString != NULL) {
      int indx; indx = 1;
      timeBoundTask *currentTBT;
      vexLog(j, "---------- Running Autonomous Task ----------");
      char *returnInfoString;
      returnInfoString = (char*) malloc((COMMAND_MAX_LEN + 100) * sizeof(char));

      if (strcmp(infoString, "All") == 0) {
        currentTBT = getTBTByIndex(indx, &rootTBT);
        while (currentTBT != NULL) {
          sprintf(returnInfoString, "..%lu", (uint64_t) currentTBT);
          vexLog(j, returnInfoString);
          sprintf(returnInfoString, "......Start time: %lu", (uint32_t) currentTBT->beginTime);
          vexLog(j, returnInfoString);
          sprintf(returnInfoString, "......End time: %lu", (uint32_t) currentTBT->endTime);
          vexLog(j, returnInfoString);
          sprintf(returnInfoString, "......Command: %s[]%s", currentTBT->formattedCommandSection1, currentTBT->formattedCommandSection2);
          vexLog(j, returnInfoString);
          indx ++;
          currentTBT = getTBTByIndex(indx, &rootTBT);
        }
        free(returnInfoString);
      } else {
        currentTBT = getTBTByAddress(infoString, rootTBT.nextptr);
        if (currentTBT == NULL) {free(argTokenList); return "[Parser V718a] Not a valid timeBoundTask* address.";}
        sprintf(returnInfoString, "..%lu", (uint64_t) currentTBT);
        vexLog(j, returnInfoString);
        sprintf(returnInfoString, "......Start time: %lu", (uint32_t) currentTBT->beginTime);
        vexLog(j, returnInfoString);
        sprintf(returnInfoString, "......End time: %lu", (uint32_t) currentTBT->endTime);
        vexLog(j, returnInfoString);
        sprintf(returnInfoString, "......Command: %s[]%s", currentTBT->formattedCommandSection1, currentTBT->formattedCommandSection2);
        vexLog(j, returnInfoString);
        free(returnInfoString);
      }
    }
    break;

    case UNDEF:
    free(argTokenList); return "[Parser V718a] Unknown command.";
    break;

    default:
    free(argTokenList); return "[Parser V718a] This command has no parameter.";
    break;
  }
    

  free(argTokenList); return "[Parser V718a] OK.";
}































int main() {


  static char thisCommand[COMMAND_MAX_LEN + 1];


  for (int i = 0; i < COMMAND_MAX_LEN; i++) {
    thisCommand[i] = ' ';
  }

  while (1) {
    for (int j = 0; j < DISPLAY_MAX_LINES; j++) {

      for (int i = 0; i < COMMAND_MAX_LEN; i++){
        thisCommand[i] = ' ';
      }

      bool endOfCommand = false;

      for (int i = 0; i < COMMAND_MAX_LEN; i++) {
        
        // Wait until there's something to receive and read the character commanded.
        while (!kbhit()) { refreshTBT(&rootTBT, &j);}
        thisCommand[i] = getch();

        // Handle the 'NULL' char exception.
        if (thisCommand[i] == 0) { thisCommand[i] = '_'; }

        // Handle the Too Long exception.
        if (i == COMMAND_MAX_LEN - 1) { endOfCommand = true; }

        // Handle the normal EOC event (two spacebars).
        if ((i != 0) && (thisCommand[i] == ' ')) { if (thisCommand[i - 1] == ' ') { endOfCommand = true; } }

        if (endOfCommand) {

          vexLog(&j, thisCommand);

          char *temp = (char*) malloc((COMMAND_MAX_LEN + 1) * sizeof(char));
          char *oritemp = temp;
          strcpy(temp, thisCommand);

          vexLog(&j, parseCommand(temp, &j) );

          free(oritemp);
          break;
        }

      }


    }
  }

}


