/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\Administrator                                    */
/*    Created:      Fri Jun 23 2023                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// ESP32                motor         20              
// RearLeft             motor         13              
// Arm                  motor         6               
// RearRight            motor         18              
// FrontLeft            motor         1               
// FrontRight           motor         10              
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
#include <string.h>

using namespace vex;

#define COMMAND_MAX_LEN 100
#define DISPLAY_MAX_LINES 12

#define _VEXSCREEN_LINEC int

// MODIFY THIS.
#define BAUDRATE 999999999

static timer pgTimer; 

typedef enum CMD {
  UNDEF,
  VEHICLE_MOTION,
  WHEELSET,
  AUTOTSK,
  ECHO
} CMD;

typedef struct timeBoundTask timeBoundTask;

typedef struct timeBoundTask {
  uint32_t beginTime;
  uint32_t endTime;
  int32_t beginValue;
  int32_t endValue;
  int32_t lastValue;
  char * formattedCommandSection1;
  char * formattedCommandSection2;
  timeBoundTask * nextptr;
  timeBoundTask * prevptr;
} timeBoundTask;

timeBoundTask rootTBT = {
  0, 0, 0, 0, 0, NULL, NULL, NULL, NULL
};

timeBoundTask *getTBTByIndex(uint32_t index, timeBoundTask * start) {
  if ((index == 0) || (start->nextptr == NULL)) {return start;}
  else {return getTBTByIndex(index - 1, start->nextptr);}
}

// Returns the first task tracing back from "start".
timeBoundTask *getIndexByTBT(uint32_t * index, timeBoundTask * start) {
  if (start->prevptr == NULL) {return start;}
  else {(*index) ++; return getIndexByTBT(index, start->prevptr);}
}

timeBoundTask *getLastTBT(timeBoundTask * start) {
  if (start->nextptr == NULL) {return start;}
  else {return getLastTBT(start->nextptr);}
}

int deleteTBT(timeBoundTask * target) {
  if (target->prevptr == NULL) {return -1;}    
  (target->prevptr)->nextptr = (target->nextptr);
  if (target->nextptr != NULL) {
    (target->nextptr)->prevptr = (target->prevptr);
  }
  free(target->formattedCommandSection1);
  free(target->formattedCommandSection2);
  free(target);
  return 0;
}

int appendAfterTBT(timeBoundTask * source, timeBoundTask * target) {
  if (target->nextptr != NULL) {
    source->nextptr = (target->nextptr)->prevptr;
    (target->nextptr)->prevptr = source;
  }
  target->nextptr = source;
  source->prevptr = target;
  return 0;
}

int32_t getCurrentValueByTime(uint32_t beginTime, uint32_t endTime, int32_t beginValue, int32_t endValue) {
  int32_t returnval = (int32_t) (beginValue + (endValue - beginValue) * ((int32_t)pgTimer.time() - (int32_t)beginTime) / ((int32_t)endTime - (int32_t)beginTime));
  if (pgTimer.time() >= endTime) {returnval = endValue;}
  return returnval;
}

char const *parseCommand(char * command, _VEXSCREEN_LINEC * j);

// Iterate through and refresh all tasks starting from "start".
int refreshTBT(timeBoundTask * start, _VEXSCREEN_LINEC * j) {
  if (start == NULL) {return 0;}
  if (start->endTime == 0) {return refreshTBT(start->nextptr, j);}

  char *tempCommand = (char*) malloc(COMMAND_MAX_LEN * sizeof(char));
  char *oritempCommand = tempCommand;
  strcpy(tempCommand, start->formattedCommandSection1);
  int32_t currentval = getCurrentValueByTime(start->beginTime, start->endTime, start->beginValue, start->endValue);
  sprintf(tempCommand + strlen(tempCommand), "%ld", currentval);
  strcat(tempCommand, start->formattedCommandSection2);
  if (start->lastValue != currentval) {parseCommand(tempCommand, j);}
  free(oritempCommand);
  start->lastValue = currentval;

  timeBoundTask *next = start->nextptr;
  if (pgTimer.time() >= start->endTime) {
    deleteTBT(start);
  }
  return refreshTBT(next, j);
}

// Detect if there is a task macro in the command.
// Creates a task at the end of the rootTPT linked list.
char const *taskMacroParse(char * command) {

  // Check the basic structure of a task macro. ([XXX])
  char *start = strchr(command, '[');
  char *end = strchr(command, ']');
  if ((start == NULL) || (end == NULL) || (end < start)) { return NULL; }

  // Allocate a piece of memory space for the string between the [ and ].
  char *substring = (char*) malloc((end - start) * sizeof(char));
  strncpy(substring, start + 1, end - start - 1);
  // Attach an \0 at the end of the char array.
  substring[end - start - 1] = '\0';

  // Allocate space for the original command before and after the macro.
  char *formattedCommand1 = (char*) malloc((strlen(command)) * sizeof(char));
  char *formattedCommand2 = (char*) malloc((strlen(command)) * sizeof(char));
  strncpy(formattedCommand1, command, start - command); 
  formattedCommand1[start - command] = '\0';
  strcpy(formattedCommand2, start + strlen(substring) + 2);
  
  // Preparations to parse the macro.
  const char *delim = ",";
  char *ptr = NULL;
  ptr = strtok(substring, delim);

  int argIndex = 0;
  bool sufficientArg = false;

  // if there's nothing inside [], then throw an exception. 
  // Notice that all allocated space MUST be freed before an abnormal exit.
  if (ptr == NULL) { free(substring); free(formattedCommand1); free(formattedCommand2); return "[Parser V716a] Task Macro lacks separator."; }

  // Allocate and config the new task.
  timeBoundTask *newTBT = (timeBoundTask*) malloc(sizeof(timeBoundTask));
  newTBT->beginTime = pgTimer.time();
  // By only allowing += operation on endTime, the program ensures that the time will only flow forwards.
  newTBT->endTime = pgTimer.time();
  newTBT->beginValue = 0;
  newTBT->endValue = 0;
  newTBT->lastValue = 0;
  newTBT->formattedCommandSection1 = formattedCommand1;
  newTBT->formattedCommandSection2 = formattedCommand2;
  // Its links in a linked list will be set later.
  newTBT->nextptr = NULL;
  newTBT->prevptr = NULL;

  while (ptr != NULL) {

    switch (argIndex) {
      case 0:
        newTBT->beginValue = atoi(ptr);
        break;
      case 1:
        newTBT->endValue = atoi(ptr);
        break;
      case 2:
        newTBT->endTime += atoi(ptr);
        sufficientArg = true;
        break;
    }
    ptr = strtok(NULL, delim);
    argIndex ++;
  }

  if (sufficientArg != true) { free(substring); free(formattedCommand1); free(formattedCommand2); free(newTBT); return "[Parser V716a] Task Macro lacks sufficient argument."; }

  // Append the newly created task to the end of the "root" list.
  appendAfterTBT(newTBT, getLastTBT(&rootTBT));

  // After parsing, the space allocated for substring must be freed.
  free(substring);

  return "[Parser V716a] New task created.";
}

// Looks up the value of a parameter in argTokenList.
// Returns the pointer to the string of the value.
// NULL if nothing is found.
char * lookUpArg(char ** argTokenList, const char * name, int argc, const char * indicator) {
  if (argTokenList == NULL) {return NULL;}
  if (indicator == NULL) {return NULL;}
  for (int i = 0; i < argc; i++) {
    // Check if the token is in the format of a command.
    if (strncmp(*(argTokenList + i), indicator, strlen(indicator)) == 0) {
      if (strncmp((*(argTokenList + i) + strlen(indicator)), name, strlen(name)) == 0) {
        if (i == argc - 1) {return NULL;}
        if (strncmp(*(argTokenList + i + 1), indicator, strlen(indicator)) == 0) {return NULL;}
        return *(argTokenList + i + 1);
      }
    }
  }
  return NULL;
}

// Parse and execute a command.
// The content of char * command needs to be modificable, so don't pass a literal to it.
// Returns an message.
char const *parseCommand(char * command, _VEXSCREEN_LINEC * j) {

  char *oricommand = command;
  const char *taskMacResponse = taskMacroParse(command);
  // If a macro is detected, then hand over the right to process to taskMacroParse().
  if (taskMacResponse != NULL) {return taskMacResponse;}

  const char *delim = " ";
  char *ptr = NULL;
  ptr = strtok(command, delim);

  CMD commandIndex = UNDEF;

  if (ptr == NULL) { return "[Parser V716a] Command seems to be empty."; }

  // The 0th argument should be the name of the command.

  if ((strcmp(ptr, "VehicleMotion") == 0) || (strcmp(ptr, "VM") == 0)) {commandIndex = VEHICLE_MOTION; } else
  if ((strcmp(ptr, "WheelSet") == 0) || (strcmp(ptr, "WS") == 0)) {commandIndex = WHEELSET;} else
  if ((strcmp(ptr, "AutonomousTask")) == 0 || (strcmp(ptr, "AT") == 0)) {commandIndex = AUTOTSK;} else
  if ((strcmp(ptr, "Echo") == 0) || (strcmp(ptr, "Print") == 0)) {commandIndex = ECHO;} else
  {commandIndex = UNDEF; return "[Parser V716a] Unknown command.";}

  // Throw an no parameter exception.
  ptr = strtok(NULL, delim);
  if (ptr == NULL) { return "[Parser V716a] Command seems to have no parameter."; }

  // Create an argTokenList according to the arguments.
  int argc = 0; // argIndex := argc - 1
  char **argTokenList = (char**) malloc(1 * sizeof(char*));
  while (ptr != NULL) {
    argc ++;
    argTokenList = (char**) realloc(argTokenList, (1 + argc) * sizeof(char*));
    *(argTokenList + argc - 1) = ptr;
    ptr = strtok(NULL, delim);
  }

  switch (commandIndex) {

    // The VehicleMotion command.
    case VEHICLE_MOTION: 
    if (lookUpArg(argTokenList, "type", argc, "-") == NULL) {free(argTokenList); return "[Parser V716a] Command lacks critical argument(s).";} 
    if (strlen(lookUpArg(argTokenList, "type", argc, "-")) != 1) {free(argTokenList); return "[Parser V716a] Unknown parameter.";}
    switch(lookUpArg(argTokenList, "type", argc, "-")[0]) {

            case 'P':  // Park
            RearLeft.stop();
            RearRight.stop();
            FrontLeft.stop();
            FrontRight.stop();
            break;

            case 'F':  // Front
            RearLeft.spin(forward);
            RearRight.spin(forward);
            FrontLeft.spin(forward);
            FrontRight.spin(forward);
            break;

            case 'B':  // Back
            RearLeft.spin(reverse);
            RearRight.spin(reverse);
            FrontLeft.spin(reverse);
            FrontRight.spin(reverse);
            break;

            case 'L':  // Left
            RearLeft.spin(reverse);
            RearRight.spin(forward);
            FrontLeft.spin(forward);
            FrontRight.spin(reverse);
            break;

            case 'R':  // Right
            RearLeft.spin(forward);
            RearRight.spin(reverse);
            FrontLeft.spin(reverse);
            FrontRight.spin(forward);
            break;

            case 'S':  // Clockwise(Shun Shi Zhen)
            RearLeft.spin(forward);
            RearRight.spin(reverse);
            FrontLeft.spin(forward);
            FrontRight.spin(reverse);
            break;

            case 'N':  // Counterclockwise(Ni Shi Zhen)
            RearLeft.spin(reverse);
            RearRight.spin(forward);
            FrontLeft.spin(reverse);
            FrontRight.spin(forward);
            break;
      
            default:
            free(argTokenList); return "[Parser V716a] Unknown parameter.";
            break;
    }
    break;

    // The WHEELSET command.
    case WHEELSET:
    typedef enum WHEEL {FR, FL, RR, RL, ALL} WHEEL;
    bool targetWheel[ALL];
    targetWheel[FR] = true; targetWheel[FL] = true; targetWheel[RR] = true; targetWheel[RL] = true; 
    char * tgwString;
    tgwString = lookUpArg(argTokenList, "target", argc, "-");
    char * speedString;
    speedString = lookUpArg(argTokenList, "speed", argc, "-");
    char * dirString;
    dirString = lookUpArg(argTokenList, "direction", argc, "-");
    if ((speedString == NULL) && (dirString == NULL)) {free(argTokenList); return "[Parser V716a] Command lacks critical argument(s).";} 

    if (tgwString != NULL) {
      if ((strcmp(tgwString, "All") != 0)) {targetWheel[FR] = false; targetWheel[FL] = false; targetWheel[RR] = false; targetWheel[RL] = false; }
      if (strstr(tgwString, "FrontR") != NULL) {targetWheel[FR] = true; }
      if (strstr(tgwString, "FrontL") != NULL) {targetWheel[FL] = true; }
      if (strstr(tgwString, "RearR") != NULL) {targetWheel[RR] = true; }
      if (strstr(tgwString, "RearL") != NULL) {targetWheel[RL] = true; }
    }

    if (speedString != NULL) {
      uint32_t spd = atoi(speedString);
      if (spd >= 100) {spd = 100;}
      if (targetWheel[RL] == true) {RearLeft.setVelocity(spd, percent);}
      if (targetWheel[RR] == true) {RearRight.setVelocity(spd, percent);}
      if (targetWheel[FL] == true) {FrontLeft.setVelocity(spd, percent);}
      if (targetWheel[FR] == true) {FrontRight.setVelocity(spd, percent);}
    }

    if (dirString != NULL) {
      if (strcmp(dirString, "Forward") == 0) {
        if (targetWheel[RL] == true) {RearLeft.spin(forward);}
        if (targetWheel[RR] == true) {RearRight.spin(forward);}
        if (targetWheel[FL] == true) {FrontLeft.spin(forward);}
        if (targetWheel[FR] == true) {FrontRight.spin(forward);}
      } else
      if ((strcmp(dirString, "Backward") == 0) || (strcmp(dirString, "Reverse") == 0)) {
        if (targetWheel[RL] == true) {RearLeft.spin(reverse);}
        if (targetWheel[RR] == true) {RearRight.spin(reverse);}
        if (targetWheel[FL] == true) {FrontLeft.spin(reverse);}
        if (targetWheel[FR] == true) {FrontRight.spin(reverse);}
      }
    }

        
    break;

    case ECHO:
    Brain.Screen.printAt( 20, 20 + 20 * (*j), oricommand );
    *j = (*j + 1) % DISPLAY_MAX_LINES;

    case UNDEF:
    free(argTokenList); return "[Parser V716a] Unknown command.";
    break;

    default:
    free(argTokenList); return "[Parser V716a] This command has no parameter.";
    break;
  }
    






  free(argTokenList); return "[Parser V716a] OK.";
}

int main() {

  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  pgTimer.reset();

  RearLeft.setVelocity(10,percent);
  RearRight.setVelocity(10,percent);
  FrontLeft.setVelocity(10,percent);
  FrontRight.setVelocity(10,percent);


  vexGenericSerialEnable(ESP32.index(), 0);
  vexGenericSerialBaudrate(ESP32.index(), BAUDRATE);

  static char thisCommand[COMMAND_MAX_LEN + 1];


  for (int i = 0; i < COMMAND_MAX_LEN; i++) {
    thisCommand[i] = ' ';
  }

  while (1) {
    for (int j = 0; j < DISPLAY_MAX_LINES; j++) {

      for (int i = 0; i < COMMAND_MAX_LEN; i++){
        thisCommand[i] = ' ';
      }

      bool endOfCommand = false;

      for (int i = 0; i < COMMAND_MAX_LEN; i++) {
        
        // Wait until there's something to receive and read the character commanded.
        while (vexGenericSerialReceiveAvail(ESP32.index()) == 0) { refreshTBT(&rootTBT, &j); }
        thisCommand[i] = vexGenericSerialReadChar(ESP32.index());

        // Handle the 'NULL' char exception.
        if (thisCommand[i] == 0) { thisCommand[i] = '_'; }

        // Handle the Too Long exception.
        if (i == COMMAND_MAX_LEN - 1) { endOfCommand = true; }

        // Handle the normal EOC event (two spacebars).
        if ((i != 0) && (thisCommand[i] == ' ')) { if (thisCommand[i - 1] == ' ') { endOfCommand = true; } }

        if (endOfCommand) {

          Brain.Screen.printAt( 20, 20 + 20 * j, thisCommand );
          j = (j + 1) % DISPLAY_MAX_LINES;

          char *temp = (char*) malloc((COMMAND_MAX_LEN + 1) * sizeof(char));
          char *oritemp = temp;
          strcpy(temp, thisCommand);

          Brain.Screen.printAt( 20, 20 + 20 * j, parseCommand(temp, &j) );
          j = (j + 1) % DISPLAY_MAX_LINES;

          free(oritemp);
          break;
        }

      }


    }
  }

}


